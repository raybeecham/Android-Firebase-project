package edu.txstate.rpb31.rentalcarapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.icu.text.NumberFormat;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.loopj.android.http.TextHttpResponseHandler;


import java.text.DecimalFormat;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;
import cz.msebera.android.httpclient.message.BasicHeader;
import cz.msebera.android.httpclient.protocol.HTTP;

public class UpdateCar extends AppCompatActivity {
    int intId;
    String strName;
    String strBrand;
    int position;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_car);

        SharedPreferences sharedPref2 = PreferenceManager.getDefaultSharedPreferences(this);
        intId = sharedPref2.getInt("id", 0);
        strName = sharedPref2.getString("name", "");
        strBrand = sharedPref2.getString("brand", "");
        position = sharedPref2.getInt("pos", 0);
        final EditText cost = findViewById(R.id.txtNewDays);

        TextView txtCarID = findViewById(R.id.txtTitle);

        txtCarID.setText("Car ID: " + intId + "\n " + strName + " " + strBrand);

        Button newDays = findViewById(R.id.btnUpdateRentalDays);


        newDays.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double dblCost = 0;
//                TextView txtTotalCost = findViewById(R.id.txtCost);

                try {
                    dblCost = Double.parseDouble(cost.getText().toString()); //int, long, float, double, boolean : primitive data type
                    cost.setText(String.format("%.2f", dblCost));





                } catch (Exception ex) {
                    Toast.makeText(UpdateCar.this, "Please enter a number", Toast.LENGTH_LONG).show();

                    return;
                }

                if (dblCost < 5) {
                    Toast.makeText(UpdateCar.this, "Please enter a number higher than 0 to 4", Toast.LENGTH_LONG).show();
                }

                else {
                String url = "cars/" +position+ "/Cost.json";
                StringEntity entity = null;
                try {
                    double newCost = Double.parseDouble(cost.getText().toString());
                    entity = new StringEntity("" + newCost); // This is a number without \".
                }  catch(Exception ex) {
                    ex.printStackTrace();
                }
                entity.setContentType(new BasicHeader(HTTP.CONTENT_TYPE, "application/text"));
                RestAPIClient.put(UpdateCar.this, url, entity,
                        "application/text", new TextHttpResponseHandler() {
                            @Override
                            public void onSuccess(int statusCode, Header[] headers, String responseString) {
                                Toast.makeText(UpdateCar.this, "You've successfully updated the cost.", Toast.LENGTH_LONG).show();

                            }

                            @Override
                            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                                Toast.makeText(UpdateCar.this, responseString, Toast.LENGTH_LONG).show();
                            }
                        });
                        }
            }
        });


        Button homeButton = (Button) findViewById(R.id.btnHome);

        homeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(UpdateCar.this, MainActivity.class));


            }
        });
    }
}