package edu.txstate.rpb31.rentalcarapp;

import android.app.ListActivity;
import android.content.Intent;
import android.content.SharedPreferences;

import android.preference.PreferenceManager;

import android.os.Bundle;

import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;


import com.loopj.android.http.JsonHttpResponseHandler;


import org.json.JSONArray;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import cz.msebera.android.httpclient.Header;

import cz.msebera.android.httpclient.message.BasicHeader;




public class RentalList extends ListActivity {

    List<Car> cars;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_rentals__list);




        getCars();
    }


    void getCars() {
        List<Header> headers = new ArrayList<>();
        headers.add(new BasicHeader("Accept", "application/json"));
        RestAPIClient.get(RentalList.this, "cars.json", headers.toArray(new Header[headers.size()]),
                null, new JsonHttpResponseHandler() {
                    public void onSuccess(int statusCode, Header[] headers, JSONArray response) {

                        cars = new ArrayList<Car>();
                        for (int i = 0; i < response.length(); i++) {
                            try {
                                cars.add(new Car(response.getJSONObject(i)));
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }
                        }
                        setListAdapter(new ArrayAdapter<Car>(RentalList.this, R.layout.activity_rental_list,
                                R.id.txtMyCars, cars));
                    }

                    public void onSuccess(int statusCode, Header[] headers, JSONObject response) {

                        cars = new ArrayList<Car>();
                        Iterator<String> keys = response.keys();
                        while (keys.hasNext()) {
                            String key = keys.next();
                            try {
                                cars.add(new Car(response.getJSONObject(key)));
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }
                        }
                        setListAdapter(new ArrayAdapter<Car>(RentalList.this, R.layout.activity_rental_list,
                                R.id.txtMyCars, cars));
                    }
                });






    }


    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {//position = index
        //super.onListItemClick(l, v, position, id);

        Car selectedCar = cars.get(position);

        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(RentalList.this);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putInt("id", selectedCar.getId());
        editor.putFloat("cost", (float) selectedCar.getCost());
        editor.putString("name", selectedCar.getName());
        editor.putString("brand", selectedCar.getBrand());
        editor.putString("color", selectedCar.getColor());
        editor.putInt("image", selectedCar.getImage());
        editor.putInt("pos", position);
        editor.commit();


        startActivity(new Intent(RentalList.this, CarInfoActivity.class));


        DecimalFormat tenth = new DecimalFormat("$###,###.00");
        Toast.makeText(RentalList.this, "You've selected a " + selectedCar.getColor() + " " + selectedCar.getName() + " " + selectedCar.getBrand() +
                ", the daily cost is " + tenth.format(selectedCar.getCost()) + ".", Toast.LENGTH_LONG).show();
    }

    //look up selected element in the array
    //String strSelectedAttraction= strAttractions[position];
    //Toast.makeText(MainActivity.this, "You select " + strSelectedAttraction + ".", Toast.LENGTH_LONG).show();


}
