package edu.txstate.rpb31.rentalcarapp;

import org.json.JSONObject;

    public class Car {
        private int id;
        private String name;
        private double cost;
        private String brand;
        private String color;
        private int image;

        public Car() {
        }

        public Car (JSONObject object){
            try {
                this.id = object.getInt("Id");
                this.cost = object.getDouble("Cost");
                this.name = object.getString("Name");
                this.brand = object.getString("Brand");
                this.color = object.getString("Color");
            }catch (Exception ex){ex.printStackTrace();}


        }

        public Car(int id, String name, double cost, String brand, String color, int image) {
            this.id = id;
            this.name = name;
            this.cost = cost;
            this.brand = brand;
            this.color = color;
            this.image = image;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public double getCost() {
            return cost;
        }

        public void setCost(double cost) {
            this.cost = cost;
        }

        public String getBrand() {
            return brand;
        }

        public void setBrand(String brand) {
            this.brand = brand;
        }

        public String getColor() {
            return color;
        }

        public void setColor(String color) {
            this.color = color;
        }

        public int getImage() {
            return image;
        }

        public void setImage(int image) {
            this.image = image;
        }

        @Override
        public String toString() {
            return "Car ID: " + this.id + "\n" + this.name + " " + this.brand;
        }
    }
