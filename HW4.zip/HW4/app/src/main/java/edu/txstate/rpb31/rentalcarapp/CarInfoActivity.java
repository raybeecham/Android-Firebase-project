package edu.txstate.rpb31.rentalcarapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import com.loopj.android.http.TextHttpResponseHandler;

import java.text.DecimalFormat;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;
import cz.msebera.android.httpclient.message.BasicHeader;
import cz.msebera.android.httpclient.protocol.HTTP;

public class CarInfoActivity extends AppCompatActivity {

//    String[] url =  {"https://firebasestorage.googleapis.com/v0/b/rentalcars-ea4f6.appspot.com/o/bluedart.jpg?alt=media&token=2d49559b-66c8-4c54-83e0-723715bfc702",
//            "https://firebasestorage.googleapis.com/v0/b/rentalcars-ea4f6.appspot.com/o/whitebuick.jpg?alt=media&token=a2524aa1-e3a3-4785-9fed-1c235bc20ae7",
//            "https://firebasestorage.googleapis.com/v0/b/rentalcars-ea4f6.appspot.com/o/silvertesla.jpg?alt=media&token=2faefdc7-ae51-4c80-94f3-92a8ea38ee0c",
//            "https://firebasestorage.googleapis.com/v0/b/rentalcars-ea4f6.appspot.com/o/redfordfive.jpg?alt=media&token=32b8f235-d0fd-49fe-8bf7-54f92ec7fd51",
//            "https://firebasestorage.googleapis.com/v0/b/rentalcars-ea4f6.appspot.com/o/blackdodgedakota.jpg?alt=media&token=f8827c7b-54f9-4d50-8f45-47bd5b36a57e"};

    int intId;
    double dblCost;
    String strName;
    String strBrand;
    String strColor;
    int carImage;
    int position;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_car_info);

        SharedPreferences sharedPref2 = PreferenceManager.getDefaultSharedPreferences(this);
        intId = sharedPref2.getInt("id", 0);
        dblCost = sharedPref2.getFloat("cost", 0);
        strName = sharedPref2.getString("name", "");
        strBrand = sharedPref2.getString("brand", "");
        strColor = sharedPref2.getString("color", "");
        carImage = sharedPref2.getInt("image", 0);
        position = sharedPref2.getInt("pos", 0);

        //ImageView carImages = (ImageView) findViewById(R.id.imgCar);
        //carImages.setImageResource(carImage);

        Button costCalculation = findViewById(R.id.btnCalculateTotal);

        TextView txtCarID = findViewById(R.id.txtCarID);

        txtCarID.setText("Car ID: " + intId);

        TextView txtCarName = findViewById(R.id.txtCarName);

        txtCarName.setText("A " + strColor + " " + strName + " " + strBrand + " is available to rent");

        DecimalFormat currency = new DecimalFormat("$###,###.00");
        String convertedCost = currency.format(dblCost);

        TextView txtCarCost = findViewById(R.id.txtCarCost);

        txtCarCost.setText("The daily cost of this car is: " + convertedCost);





        final EditText txtNumberOfMonths = findViewById(R.id.txtRentalDays);
        costCalculation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int intDays = 0;
//                TextView txtTotalCost = findViewById(R.id.txtCost);

                try {
                    intDays = Integer.parseInt(txtNumberOfMonths.getText().toString()); //int, long, float, double, boolean : primitive data type
                } catch (Exception ex) {
                    Toast.makeText(CarInfoActivity.this, "Please enter a number", Toast.LENGTH_LONG).show();



                    return;

                }

                if (intDays == 0) {
                    Toast.makeText(CarInfoActivity.this, "Please enter an integer higher than 0.", Toast.LENGTH_LONG).show();
                    //txtTotalCost.setText("");
                }
                else if (intDays > 30) {
                    double dblTotalCost = dblCost * intDays;
                    DecimalFormat currency = new DecimalFormat("$###,###.00");
                    //TextView txtTotalCost = findViewById(R.id.txtTotalCost);
                    Toast.makeText(CarInfoActivity.this, "Please call 512-777-2222 for further instructions.", Toast.LENGTH_LONG).show();
                }
                else {
                    double dblTotalCost = dblCost * intDays;
                    DecimalFormat currency = new DecimalFormat("$###,###.00");
                    Toast.makeText(CarInfoActivity.this, "Your total cost for " + intDays + " days is: " + currency.format(dblTotalCost), Toast.LENGTH_LONG).show();
                }



            }
        });


        Button addCar = findViewById(R.id.btnUpdate);
        addCar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(CarInfoActivity.this, UpdateCar.class));
            }
        });
    }
}